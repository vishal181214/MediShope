<?php

include "constants.php";

$servername = "localhost";
$username = "root";
$password = "";
$db = "mybd";


$con = mysqli_connect($servername, $username, $password,$db);


if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


?>






